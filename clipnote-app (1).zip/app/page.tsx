"use client"

import { useState } from "react"
import { AuthProvider } from "@/components/auth-provider"
import { Header } from "@/components/header"
import { ClipManager } from "@/components/clip-manager"
import { AuthModal } from "@/components/auth-modal"
import { NotificationSystem } from "@/components/notification-system"
import { useTheme } from "@/hooks/use-theme"

export default function Home() {
  const [showAuthModal, setShowAuthModal] = useState(false)
  const { theme } = useTheme()

  return (
    <AuthProvider>
      <div className={`min-h-screen transition-all duration-300 ${theme === "dark" ? "dark" : ""}`}>
        <div className="bg-background text-foreground">
          <Header onShowAuth={() => setShowAuthModal(true)} />
          <main className="container mx-auto px-4 py-6">
            <ClipManager />
          </main>
          {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
          <NotificationSystem />
        </div>
      </div>
    </AuthProvider>
  )
}

"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth-provider"
import { useNotifications } from "@/hooks/use-notifications"
import type { Clip } from "@/types/clip"

export function useClips() {
  const [clips, setClips] = useState<Clip[]>([])
  const { user } = useAuth()
  const { addNotification } = useNotifications()

  // Load clips from localStorage
  useEffect(() => {
    if (user) {
      const savedClips = localStorage.getItem(`transform-clips-${user.id}`)
      if (savedClips) {
        try {
          const parsedClips = JSON.parse(savedClips).map((clip: any) => ({
            ...clip,
            createdAt: new Date(clip.createdAt),
            updatedAt: new Date(clip.updatedAt),
          }))
          setClips(parsedClips)
        } catch (error) {
          console.error("Failed to load clips:", error)
        }
      }
    }
  }, [user])

  // Save clips to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem(`transform-clips-${user.id}`, JSON.stringify(clips))
    }
  }, [clips, user])

  const addClip = (clipData: Omit<Clip, "id" | "createdAt" | "updatedAt" | "userId">) => {
    const newClip: Clip = {
      id: crypto.randomUUID(),
      userId: user?.id || "guest",
      createdAt: new Date(),
      updatedAt: new Date(),
      ...clipData,
    }
    setClips((prev) => [newClip, ...prev])
    addNotification({
      type: "success",
      title: "Clip saved!",
      message: "Your clip has been saved successfully.",
    })
  }

  const updateClip = (id: string, updates: Partial<Omit<Clip, "id" | "createdAt" | "userId">>) => {
    setClips((prev) =>
      prev.map((clip) =>
        clip.id === id
          ? {
              ...clip,
              ...updates,
              updatedAt: new Date(),
            }
          : clip,
      ),
    )
    addNotification({
      type: "success",
      title: "Clip updated!",
      message: "Your changes have been saved.",
    })
  }

  const deleteClip = (id: string) => {
    setClips((prev) => prev.filter((clip) => clip.id !== id))
    addNotification({
      type: "info",
      title: "Clip deleted",
      message: "The clip has been removed.",
    })
  }

  const searchClips = (query: string, tags: string[], includeArchived = false) => {
    return clips.filter((clip) => {
      if (!includeArchived && clip.isArchived) return false

      const matchesQuery =
        !query ||
        clip.content.toLowerCase().includes(query.toLowerCase()) ||
        clip.title?.toLowerCase().includes(query.toLowerCase()) ||
        clip.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase()))

      const matchesTags = tags.length === 0 || tags.every((tag) => clip.tags.includes(tag))

      return matchesQuery && matchesTags
    })
  }

  return {
    clips,
    addClip,
    updateClip,
    deleteClip,
    searchClips,
  }
}

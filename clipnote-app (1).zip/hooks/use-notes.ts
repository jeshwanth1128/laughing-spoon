"use client"

import { useState, useEffect } from "react"
import type { Note } from "@/types/note"

export function useNotes() {
  const [notes, setNotes] = useState<Note[]>([])

  // Load notes from localStorage on mount
  useEffect(() => {
    const savedNotes = localStorage.getItem("clipnote-notes")
    if (savedNotes) {
      try {
        const parsedNotes = JSON.parse(savedNotes).map((note: any) => ({
          ...note,
          createdAt: new Date(note.createdAt),
        }))
        setNotes(parsedNotes)
      } catch (error) {
        console.error("Failed to load notes:", error)
      }
    }
  }, [])

  // Save notes to localStorage whenever notes change
  useEffect(() => {
    localStorage.setItem("clipnote-notes", JSON.stringify(notes))
  }, [notes])

  const addNote = (noteData: Omit<Note, "id" | "createdAt">) => {
    const newNote: Note = {
      id: crypto.randomUUID(),
      createdAt: new Date(),
      ...noteData,
    }
    setNotes((prev) => [newNote, ...prev])
  }

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((note) => note.id !== id))
  }

  const searchNotes = (query: string, tags: string[]) => {
    return notes.filter((note) => {
      const matchesQuery =
        !query ||
        note.content.toLowerCase().includes(query.toLowerCase()) ||
        note.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase()))

      const matchesTags = tags.length === 0 || tags.every((tag) => note.tags.includes(tag))

      return matchesQuery && matchesTags
    })
  }

  return {
    notes,
    addNote,
    deleteNote,
    searchNotes,
  }
}

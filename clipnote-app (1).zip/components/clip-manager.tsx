"use client"

import { useState } from "react"
import { Plus, Search, Filter, Archive, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ClipCard } from "@/components/clip-card"
import { ClipEditor } from "@/components/clip-editor"
import { AnalyticsDashboard } from "@/components/analytics-dashboard"
import { useClips } from "@/hooks/use-clips"
import { useAuth } from "@/components/auth-provider"
import type { Clip } from "@/types/clip"

export function ClipManager() {
  const { user } = useAuth()
  const { clips, addClip, updateClip, deleteClip, searchClips } = useClips()
  const [showEditor, setShowEditor] = useState(false)
  const [editingClip, setEditingClip] = useState<Clip | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [showArchived, setShowArchived] = useState(false)
  const [showAnalytics, setShowAnalytics] = useState(false)

  const filteredClips = searchClips(searchQuery, selectedTags, showArchived)
  const allTags = Array.from(new Set(clips.flatMap((clip) => clip.tags)))

  const handleSaveClip = (clipData: Omit<Clip, "id" | "createdAt" | "updatedAt" | "userId">) => {
    if (editingClip) {
      updateClip(editingClip.id, clipData)
    } else {
      addClip(clipData)
    }
    setShowEditor(false)
    setEditingClip(null)
  }

  const handleEditClip = (clip: Clip) => {
    setEditingClip(clip)
    setShowEditor(true)
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Welcome Section */}
      <div className="text-center py-8">
        <h2 className="text-3xl font-bold mb-2 text-foreground">Welcome back, {user?.name?.split(" ")[0]}! 👋</h2>
        <p className="text-muted-foreground mb-6">
          {clips.length === 0
            ? "Start capturing your ideas and organize them with intelligent tagging"
            : `You have ${clips.length} clips organized and ready`}
        </p>
        <div className="flex justify-center space-x-4">
          <Button onClick={() => setShowEditor(true)} className="neumorphic-button-primary">
            <Plus className="h-4 w-4 mr-2" />
            New Clip
          </Button>
          <Button variant="outline" onClick={() => setShowAnalytics(true)} className="neumorphic-button">
            <TrendingUp className="h-4 w-4 mr-2" />
            Analytics
          </Button>
        </div>
      </div>

      {/* Filter Controls */}
      {clips.length > 0 && (
        <div className="neumorphic-card p-4 space-y-4">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {allTags.map((tag) => (
                <Button
                  key={tag}
                  variant={selectedTags.includes(tag) ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setSelectedTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]))
                  }}
                  className={`text-xs ${selectedTags.includes(tag) ? "accent-element" : "neumorphic-button"}`}
                >
                  {tag}
                </Button>
              ))}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowArchived(!showArchived)}
              className="neumorphic-button"
            >
              <Archive className="h-4 w-4 mr-1" />
              {showArchived ? "Hide Archived" : "Show Archived"}
            </Button>
          </div>
        </div>
      )}

      {/* Clips Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClips.map((clip) => (
          <ClipCard
            key={clip.id}
            clip={clip}
            onEdit={() => handleEditClip(clip)}
            onDelete={() => deleteClip(clip.id)}
            onTogglePin={() => updateClip(clip.id, { isPinned: !clip.isPinned })}
            onToggleArchive={() => updateClip(clip.id, { isArchived: !clip.isArchived })}
          />
        ))}
      </div>

      {/* Empty State */}
      {filteredClips.length === 0 && clips.length === 0 && (
        <div className="text-center py-12">
          <div className="w-24 h-24 mx-auto mb-6 bg-muted border-2 border-border rounded-full flex items-center justify-center">
            <Plus className="w-12 h-12 text-foreground" />
          </div>
          <h3 className="text-xl font-semibold mb-2">No clips yet</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Start capturing your thoughts, ideas, and important information. Use tags to organize and find them easily.
          </p>
          <Button onClick={() => setShowEditor(true)} className="neumorphic-button-primary">
            Create Your First Clip
          </Button>
        </div>
      )}

      {/* No Search Results */}
      {filteredClips.length === 0 && clips.length > 0 && (
        <div className="text-center py-8">
          <Search className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-lg font-medium mb-2">No clips found</h3>
          <p className="text-muted-foreground">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {/* Clip Editor Modal */}
      {showEditor && (
        <ClipEditor
          clip={editingClip}
          onSave={handleSaveClip}
          onClose={() => {
            setShowEditor(false)
            setEditingClip(null)
          }}
        />
      )}

      {/* Analytics Dashboard */}
      {showAnalytics && <AnalyticsDashboard clips={clips} onClose={() => setShowAnalytics(false)} />}
    </div>
  )
}

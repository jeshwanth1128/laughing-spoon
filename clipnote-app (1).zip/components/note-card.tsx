"use client"

import { useState } from "react"
import { MoreVertical, Trash2, Share, Link, Type, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import type { Note } from "@/types/note"

interface NoteCardProps {
  note: Note
  onDelete: () => void
}

export function NoteCard({ note, onDelete }: NoteCardProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const isLongContent = note.content.length > 150
  const displayContent = isExpanded || !isLongContent ? note.content : note.content.slice(0, 150) + "..."

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "ClipNote",
        text: note.content,
      })
    } else {
      navigator.clipboard.writeText(note.content)
    }
  }

  return (
    <div className="group bg-card border rounded-lg p-4 hover:shadow-md transition-all duration-200 hover:border-accent/50">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-2">
          {note.type === "link" ? (
            <Link className="h-4 w-4 text-accent" />
          ) : (
            <Type className="h-4 w-4 text-muted-foreground" />
          )}
          <span className="text-xs text-muted-foreground flex items-center">
            <Calendar className="h-3 w-3 mr-1" />
            {formatDate(note.createdAt)}
          </span>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={handleShare}>
              <Share className="h-4 w-4 mr-2" />
              Share
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onDelete} className="text-destructive">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="space-y-3">
        <p
          className="text-sm text-foreground leading-relaxed cursor-pointer"
          onClick={() => isLongContent && setIsExpanded(!isExpanded)}
        >
          {displayContent}
          {isLongContent && (
            <button className="text-accent hover:underline ml-1 text-xs">
              {isExpanded ? "Show less" : "Show more"}
            </button>
          )}
        </p>

        {note.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {note.tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

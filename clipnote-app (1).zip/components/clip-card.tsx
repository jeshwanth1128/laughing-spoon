"use client"

import { useState } from "react"
import { MoreVertical, Pin, Archive, Edit, Trash2, Share, Calendar, Tag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import type { Clip } from "@/types/clip"

interface ClipCardProps {
  clip: Clip
  onEdit: () => void
  onDelete: () => void
  onTogglePin: () => void
  onToggleArchive: () => void
}

export function ClipCard({ clip, onEdit, onDelete, onTogglePin, onToggleArchive }: ClipCardProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const isLongContent = clip.content.length > 200
  const displayContent = isExpanded || !isLongContent ? clip.content : clip.content.slice(0, 200) + "..."

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "TRANSFORM Clip",
        text: clip.content,
      })
    } else {
      navigator.clipboard.writeText(clip.content)
    }
  }

  return (
    <div
      className={`group neumorphic-card p-6 hover:shadow-xl transition-all duration-300 ${
        clip.isPinned ? "ring-2 ring-foreground" : ""
      } ${clip.isArchived ? "opacity-60" : ""}`}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-2">
          {clip.isPinned && <Pin className="h-4 w-4 text-foreground fill-current" />}
          <span className="text-xs text-muted-foreground flex items-center">
            <Calendar className="h-3 w-3 mr-1" />
            {formatDate(clip.createdAt)}
          </span>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity neumorphic-button"
            >
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="neumorphic-card">
            <DropdownMenuItem onClick={onEdit} className="interactive-hover">
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onTogglePin} className="interactive-hover">
              <Pin className="h-4 w-4 mr-2" />
              {clip.isPinned ? "Unpin" : "Pin"}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onToggleArchive} className="interactive-hover">
              <Archive className="h-4 w-4 mr-2" />
              {clip.isArchived ? "Unarchive" : "Archive"}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleShare} className="interactive-hover">
              <Share className="h-4 w-4 mr-2" />
              Share
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onDelete} className="interactive-hover">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Content */}
      <div className="space-y-4">
        {clip.title && <h3 className="font-semibold text-lg leading-tight text-foreground">{clip.title}</h3>}

        <div
          className="text-sm text-foreground leading-relaxed cursor-pointer"
          onClick={() => isLongContent && setIsExpanded(!isExpanded)}
        >
          {clip.content.startsWith("```") ? (
            <pre className="bg-muted p-3 rounded-lg overflow-x-auto text-xs border border-border">
              <code>{displayContent}</code>
            </pre>
          ) : (
            <p className="whitespace-pre-wrap">{displayContent}</p>
          )}
          {isLongContent && (
            <button className="text-foreground hover:underline ml-1 text-xs font-medium border-b border-foreground">
              {isExpanded ? "Show less" : "Show more"}
            </button>
          )}
        </div>

        {/* Tags */}
        {clip.tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            <Tag className="h-3 w-3 text-muted-foreground mt-1" />
            {clip.tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs neumorphic-tag">
                {tag}
              </Badge>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

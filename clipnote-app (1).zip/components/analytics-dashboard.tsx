"use client"

import { X, TrendingUp, Hash, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Clip } from "@/types/clip"

interface AnalyticsDashboardProps {
  clips: Clip[]
  onClose: () => void
}

export function AnalyticsDashboard({ clips, onClose }: AnalyticsDashboardProps) {
  const totalClips = clips.length
  const pinnedClips = clips.filter((clip) => clip.isPinned).length
  const archivedClips = clips.filter((clip) => clip.isArchived).length

  // Tag analytics
  const tagCounts = clips.reduce(
    (acc, clip) => {
      clip.tags.forEach((tag) => {
        acc[tag] = (acc[tag] || 0) + 1
      })
      return acc
    },
    {} as Record<string, number>,
  )

  const topTags = Object.entries(tagCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10)

  // Creation trends (last 7 days)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date()
    date.setDate(date.getDate() - i)
    return date.toDateString()
  }).reverse()

  const creationTrends = last7Days.map((dateString) => {
    const count = clips.filter((clip) => clip.createdAt.toDateString() === dateString).length
    return { date: dateString, count }
  })

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="neumorphic-card w-full max-w-4xl max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border/50">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-semibold">Analytics Dashboard</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="neumorphic-button">
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8 overflow-y-auto max-h-[calc(90vh-80px)]">
          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="neumorphic-card p-4 text-center">
              <div className="text-2xl font-bold text-primary">{totalClips}</div>
              <div className="text-sm text-muted-foreground">Total Clips</div>
            </div>
            <div className="neumorphic-card p-4 text-center">
              <div className="text-2xl font-bold text-accent">{pinnedClips}</div>
              <div className="text-sm text-muted-foreground">Pinned</div>
            </div>
            <div className="neumorphic-card p-4 text-center">
              <div className="text-2xl font-bold text-muted-foreground">{archivedClips}</div>
              <div className="text-sm text-muted-foreground">Archived</div>
            </div>
            <div className="neumorphic-card p-4 text-center">
              <div className="text-2xl font-bold text-primary">{Object.keys(tagCounts).length}</div>
              <div className="text-sm text-muted-foreground">Unique Tags</div>
            </div>
          </div>

          {/* Top Tags */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center">
              <Hash className="h-5 w-5 mr-2" />
              Most Common Tags
            </h3>
            <div className="neumorphic-card p-4">
              {topTags.length > 0 ? (
                <div className="space-y-3">
                  {topTags.map(([tag, count], index) => (
                    <div key={tag} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <span className="text-sm font-medium text-muted-foreground w-6">#{index + 1}</span>
                        <Badge variant="secondary" className="neumorphic-tag">
                          {tag}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-muted rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full transition-all duration-300"
                            style={{ width: `${(count / topTags[0][1]) * 100}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium w-8 text-right">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-4">No tags yet</p>
              )}
            </div>
          </div>

          {/* Creation Trends */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Clip Creation Trends (Last 7 Days)
            </h3>
            <div className="neumorphic-card p-4">
              <div className="space-y-3">
                {creationTrends.map(({ date, count }) => (
                  <div key={date} className="flex items-center justify-between">
                    <span className="text-sm">
                      {new Date(date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
                    </span>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-muted rounded-full h-2">
                        <div
                          className="bg-accent h-2 rounded-full transition-all duration-300"
                          style={{
                            width: `${Math.max(creationTrends) ? (count / Math.max(...creationTrends.map((t) => t.count))) * 100 : 0}%`,
                          }}
                        />
                      </div>
                      <span className="text-sm font-medium w-8 text-right">{count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Recent Activity</h3>
            <div className="neumorphic-card p-4">
              <div className="space-y-3">
                {clips.slice(0, 5).map((clip) => (
                  <div key={clip.id} className="flex items-start space-x-3 p-2 rounded-lg hover:bg-muted/50">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{clip.title || clip.content.slice(0, 50) + "..."}</p>
                      <p className="text-xs text-muted-foreground">
                        {clip.createdAt.toLocaleDateString()} • {clip.tags.length} tags
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

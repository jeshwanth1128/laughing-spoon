"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth-provider"
import { useNotifications } from "@/hooks/use-notifications"
import type { Clip } from "@/types/clip"

export function useClips() {
  const [clips, setClips] = useState<Clip[]>([])
  const [mounted, setMounted] = useState(false)
  const { user } = useAuth()
  const { addNotification } = useNotifications()

  useEffect(() => {
    setMounted(true)
  }, [])

  // Load clips from localStorage
  useEffect(() => {
    if (!mounted || !user) return

    try {
      const savedClips = localStorage.getItem(`transform-clips-${user.id}`)
      if (savedClips) {
        const parsedClips = JSON.parse(savedClips).map((clip: any) => ({
          ...clip,
          createdAt: new Date(clip.createdAt),
          updatedAt: new Date(clip.updatedAt),
        }))
        setClips(parsedClips)
      }
    } catch (error) {
      console.error("Failed to load clips:", error)
      setClips([])
    }
  }, [user, mounted])

  // Save clips to localStorage
  useEffect(() => {
    if (!mounted || !user) return

    try {
      localStorage.setItem(`transform-clips-${user.id}`, JSON.stringify(clips))
    } catch (error) {
      console.error("Failed to save clips:", error)
    }
  }, [clips, user, mounted])

  const addClip = (clipData: Omit<Clip, "id" | "createdAt" | "updatedAt" | "userId">) => {
    try {
      const newClip: Clip = {
        id: crypto.randomUUID(),
        userId: user?.id || "guest",
        createdAt: new Date(),
        updatedAt: new Date(),
        ...clipData,
      }
      setClips((prev) => [newClip, ...prev])
      addNotification({
        type: "success",
        title: "Clip saved!",
        message: "Your clip has been saved successfully.",
      })
    } catch (error) {
      console.error("Failed to add clip:", error)
      addNotification({
        type: "error",
        title: "Error",
        message: "Failed to save clip. Please try again.",
      })
    }
  }

  const updateClip = (id: string, updates: Partial<Omit<Clip, "id" | "createdAt" | "userId">>) => {
    try {
      setClips((prev) =>
        prev.map((clip) =>
          clip.id === id
            ? {
                ...clip,
                ...updates,
                updatedAt: new Date(),
              }
            : clip,
        ),
      )
      addNotification({
        type: "success",
        title: "Clip updated!",
        message: "Your changes have been saved.",
      })
    } catch (error) {
      console.error("Failed to update clip:", error)
      addNotification({
        type: "error",
        title: "Error",
        message: "Failed to update clip. Please try again.",
      })
    }
  }

  const deleteClip = (id: string) => {
    try {
      setClips((prev) => prev.filter((clip) => clip.id !== id))
      addNotification({
        type: "info",
        title: "Clip deleted",
        message: "The clip has been removed.",
      })
    } catch (error) {
      console.error("Failed to delete clip:", error)
      addNotification({
        type: "error",
        title: "Error",
        message: "Failed to delete clip. Please try again.",
      })
    }
  }

  const searchClips = (query: string, tags: string[], includeArchived = false) => {
    try {
      return clips.filter((clip) => {
        if (!includeArchived && clip.isArchived) return false

        const matchesQuery =
          !query ||
          clip.content.toLowerCase().includes(query.toLowerCase()) ||
          clip.title?.toLowerCase().includes(query.toLowerCase()) ||
          clip.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase()))

        const matchesTags = tags.length === 0 || tags.every((tag) => clip.tags.includes(tag))

        return matchesQuery && matchesTags
      })
    } catch (error) {
      console.error("Failed to search clips:", error)
      return []
    }
  }

  return {
    clips,
    addClip,
    updateClip,
    deleteClip,
    searchClips,
  }
}

"use client"

import { useState, useEffect } from "react"

export function useTheme() {
  const [theme, setTheme] = useState<"light" | "dark">("light")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return

    try {
      // Check system preference
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
      const savedTheme = localStorage.getItem("transform-theme") as "light" | "dark" | null

      setTheme(savedTheme || systemTheme)
    } catch (error) {
      console.error("Failed to load theme:", error)
      setTheme("light")
    }
  }, [mounted])

  useEffect(() => {
    if (!mounted) return

    try {
      localStorage.setItem("transform-theme", theme)
      document.documentElement.classList.toggle("dark", theme === "dark")
    } catch (error) {
      console.error("Failed to save theme:", error)
    }
  }, [theme, mounted])

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"))
  }

  return { theme, toggleTheme }
}

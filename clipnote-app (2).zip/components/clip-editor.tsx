"use client"

import { useState } from "react"
import { X, Save, Mic, Hash, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import type { Clip } from "@/types/clip"

interface ClipEditorProps {
  clip?: Clip | null
  onSave: (clip: Omit<Clip, "id" | "createdAt" | "updatedAt" | "userId">) => void
  onClose: () => void
}

const SUGGESTED_TAGS = [
  "idea",
  "todo",
  "quote",
  "code",
  "meeting",
  "research",
  "inspiration",
  "reminder",
  "project",
  "learning",
]

export function ClipEditor({ clip, onSave, onClose }: ClipEditorProps) {
  const [title, setTitle] = useState(clip?.title || "")
  const [content, setContent] = useState(clip?.content || "")
  const [tags, setTags] = useState<string[]>(clip?.tags || [])
  const [newTag, setNewTag] = useState("")
  const [isPinned, setIsPinned] = useState(clip?.isPinned || false)
  const [isListening, setIsListening] = useState(false)

  const handleSave = () => {
    if (!content.trim()) return

    onSave({
      title: title.trim() || undefined,
      content: content.trim(),
      tags,
      isPinned,
      isArchived: clip?.isArchived || false,
    })
  }

  const addTag = (tag: string) => {
    if (tag && !tags.includes(tag)) {
      setTags([...tags, tag])
    }
    setNewTag("")
  }

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const handleSpeechToText = () => {
    if (!("webkitSpeechRecognition" in window)) {
      alert("Speech recognition not supported in this browser")
      return
    }

    const recognition = new (window as any).webkitSpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = false
    recognition.lang = "en-US"

    recognition.onstart = () => setIsListening(true)
    recognition.onend = () => setIsListening(false)

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript
      setContent((prev) => prev + (prev ? " " : "") + transcript)
    }

    recognition.onerror = () => {
      setIsListening(false)
      alert("Speech recognition error")
    }

    recognition.start()
  }

  const generateAITags = () => {
    // Simulate AI tag generation
    const words = content.toLowerCase().split(/\s+/)
    const aiTags = SUGGESTED_TAGS.filter((tag) => words.some((word) => word.includes(tag.slice(0, 3))))
    const newTags = aiTags.filter((tag) => !tags.includes(tag)).slice(0, 3)
    setTags([...tags, ...newTags])
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="neumorphic-card w-full max-w-2xl max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border/50">
          <h2 className="text-xl font-semibold">{clip ? "Edit Clip" : "New Clip"}</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="neumorphic-button">
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {/* Title */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Title (optional)</label>
            <Input
              placeholder="Enter a title for your clip..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="neumorphic-input"
            />
          </div>

          {/* Content */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Content</label>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSpeechToText}
                disabled={isListening}
                className="neumorphic-button bg-transparent"
              >
                <Mic className={`h-4 w-4 mr-2 ${isListening ? "text-red-500 animate-pulse" : ""}`} />
                {isListening ? "Listening..." : "Voice Input"}
              </Button>
            </div>
            <Textarea
              placeholder="What's on your mind?"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[200px] resize-none neumorphic-input"
              autoFocus
            />
          </div>

          {/* Tags */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium flex items-center">
                <Hash className="h-4 w-4 mr-1" />
                Tags
              </label>
              <Button
                variant="outline"
                size="sm"
                onClick={generateAITags}
                disabled={!content.trim()}
                className="neumorphic-button bg-transparent"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                AI Suggest
              </Button>
            </div>

            {/* Selected Tags */}
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground neumorphic-tag"
                    onClick={() => removeTag(tag)}
                  >
                    {tag} ×
                  </Badge>
                ))}
              </div>
            )}

            {/* Add New Tag */}
            <div className="flex space-x-2">
              <Input
                placeholder="Add tag..."
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && addTag(newTag)}
                className="flex-1 neumorphic-input"
              />
              <Button
                variant="outline"
                onClick={() => addTag(newTag)}
                disabled={!newTag.trim()}
                className="neumorphic-button"
              >
                Add
              </Button>
            </div>

            {/* Suggested Tags */}
            <div className="flex flex-wrap gap-2">
              {SUGGESTED_TAGS.filter((tag) => !tags.includes(tag)).map((tag) => (
                <Badge
                  key={tag}
                  variant="outline"
                  className="cursor-pointer hover:bg-accent hover:text-accent-foreground neumorphic-tag"
                  onClick={() => addTag(tag)}
                >
                  + {tag}
                </Badge>
              ))}
            </div>
          </div>

          {/* Options */}
          <div className="flex items-center space-x-3">
            <Switch checked={isPinned} onCheckedChange={setIsPinned} />
            <label className="text-sm font-medium">Pin this clip</label>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end space-x-3 p-6 border-t border-border/50">
          <Button variant="outline" onClick={onClose} className="neumorphic-button bg-transparent">
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!content.trim()} className="neumorphic-button-primary">
            <Save className="h-4 w-4 mr-2" />
            Save Clip
          </Button>
        </div>
      </div>
    </div>
  )
}

"use client"

import { X, Calendar, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Note } from "@/types/note"

interface DailyDigestProps {
  notes: Note[]
  onClose: () => void
}

export function DailyDigest({ notes, onClose }: DailyDigestProps) {
  const today = new Date()
  const todayNotes = notes.filter((note) => {
    const noteDate = new Date(note.createdAt)
    return noteDate.toDateString() === today.toDateString()
  })

  const recentNotes = notes.slice(0, 5)
  const topTags = getTopTags(notes)

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-background rounded-xl shadow-2xl w-full max-w-lg max-h-[80vh] overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-accent" />
            <h2 className="text-lg font-semibold">Today's Mind Clips</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-4 space-y-6 overflow-y-auto max-h-[calc(80vh-80px)]">
          {/* Today's Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-accent/10 rounded-lg">
              <div className="text-2xl font-bold text-accent">{todayNotes.length}</div>
              <div className="text-sm text-muted-foreground">Clips Today</div>
            </div>
            <div className="text-center p-3 bg-accent/10 rounded-lg">
              <div className="text-2xl font-bold text-accent">{notes.length}</div>
              <div className="text-sm text-muted-foreground">Total Clips</div>
            </div>
          </div>

          {/* Top Tags */}
          {topTags.length > 0 && (
            <div>
              <h3 className="font-medium mb-2 flex items-center">
                <TrendingUp className="h-4 w-4 mr-2" />
                Popular Tags
              </h3>
              <div className="flex flex-wrap gap-2">
                {topTags.map(({ tag, count }) => (
                  <Badge key={tag} variant="secondary">
                    {tag} ({count})
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Recent Clips */}
          <div>
            <h3 className="font-medium mb-3">Recent Clips</h3>
            <div className="space-y-3">
              {recentNotes.length > 0 ? (
                recentNotes.map((note) => (
                  <div key={note.id} className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-foreground line-clamp-2 mb-2">{note.content}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-wrap gap-1">
                        {note.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {note.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{note.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Intl.DateTimeFormat("en-US", {
                          hour: "2-digit",
                          minute: "2-digit",
                        }).format(note.createdAt)}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No clips yet. Start capturing your ideas!
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function getTopTags(notes: Note[]) {
  const tagCounts = notes.reduce(
    (acc, note) => {
      note.tags.forEach((tag) => {
        acc[tag] = (acc[tag] || 0) + 1
      })
      return acc
    },
    {} as Record<string, number>,
  )

  return Object.entries(tagCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)
    .map(([tag, count]) => ({ tag, count }))
}

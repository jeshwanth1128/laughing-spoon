"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  email: string
  name: string
  isGuest: boolean
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<void>
  loginWithGoogle: () => Promise<void>
  loginAsGuest: () => void
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return

    try {
      // Check for existing session
      const savedUser = localStorage.getItem("transform-user")
      if (savedUser) {
        const parsedUser = JSON.parse(savedUser)
        setUser(parsedUser)
      } else {
        // Auto-login as guest if no user found
        loginAsGuest()
      }
    } catch (error) {
      console.error("Failed to load user session:", error)
      loginAsGuest()
    } finally {
      setIsLoading(false)
    }
  }, [mounted])

  const login = async (email: string, password: string) => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      const newUser: User = {
        id: crypto.randomUUID(),
        email,
        name: email.split("@")[0],
        isGuest: false,
      }
      setUser(newUser)
      if (typeof window !== "undefined") {
        localStorage.setItem("transform-user", JSON.stringify(newUser))
      }
    } catch (error) {
      console.error("Login failed:", error)
      // Fallback to guest mode on login failure
      loginAsGuest()
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const loginWithGoogle = async () => {
    setIsLoading(true)
    try {
      // Simulate Google OAuth
      await new Promise((resolve) => setTimeout(resolve, 1000))
      const newUser: User = {
        id: crypto.randomUUID(),
        email: "user@gmail.com",
        name: "Google User",
        isGuest: false,
      }
      setUser(newUser)
      if (typeof window !== "undefined") {
        localStorage.setItem("transform-user", JSON.stringify(newUser))
      }
    } catch (error) {
      console.error("Google login failed:", error)
      loginAsGuest()
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const loginAsGuest = () => {
    const guestUser: User = {
      id: "guest-" + crypto.randomUUID(),
      email: "guest@transform.app",
      name: "Guest User",
      isGuest: true,
    }
    setUser(guestUser)
    if (typeof window !== "undefined") {
      localStorage.setItem("transform-user", JSON.stringify(guestUser))
    }
  }

  const logout = () => {
    setUser(null)
    if (typeof window !== "undefined") {
      localStorage.removeItem("transform-user")
      localStorage.removeItem("transform-clips")
    }
    loginAsGuest()
  }

  // Don't render children until mounted and user is loaded
  if (!mounted || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-black border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-black">Initializing...</p>
        </div>
      </div>
    )
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        loginWithGoogle,
        loginAsGuest,
        logout,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

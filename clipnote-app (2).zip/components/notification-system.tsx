"use client"

import { useState, useEffect } from "react"
import { X, Bell, CheckCircle, AlertCircle, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useNotifications } from "@/hooks/use-notifications"

export function NotificationSystem() {
  const { notifications, removeNotification } = useNotifications()
  const [visibleNotifications, setVisibleNotifications] = useState<string[]>([])

  useEffect(() => {
    notifications.forEach((notification) => {
      if (!visibleNotifications.includes(notification.id)) {
        setVisibleNotifications((prev) => [...prev, notification.id])

        // Auto-remove after 5 seconds
        setTimeout(() => {
          removeNotification(notification.id)
          setVisibleNotifications((prev) => prev.filter((id) => id !== notification.id))
        }, 5000)
      }
    })
  }, [notifications, visibleNotifications, removeNotification])

  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-foreground" />
      case "error":
        return <AlertCircle className="h-5 w-5 text-foreground" />
      case "info":
        return <Info className="h-5 w-5 text-foreground" />
      default:
        return <Bell className="h-5 w-5 text-foreground" />
    }
  }

  return (
    <div className="fixed top-20 right-4 z-50 space-y-2">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className="neumorphic-card p-4 max-w-sm animate-in slide-in-from-right-4 duration-300"
        >
          <div className="flex items-start space-x-3">
            {getIcon(notification.type)}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">{notification.title}</p>
              {notification.message && <p className="text-xs text-muted-foreground mt-1">{notification.message}</p>}
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 neumorphic-button"
              onClick={() => {
                removeNotification(notification.id)
                setVisibleNotifications((prev) => prev.filter((id) => id !== notification.id))
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}

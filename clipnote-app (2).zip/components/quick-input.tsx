"use client"

import { useState } from "react"
import { X, Link, Type, Tag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import type { Note } from "@/types/note"

interface QuickInputProps {
  onSave: (note: Omit<Note, "id" | "createdAt">) => void
  onClose: () => void
}

const SUGGESTED_TAGS = ["AI", "hackathon", "quote", "tool", "idea", "inspiration", "learning"]

export function QuickInput({ onSave, onClose }: QuickInputProps) {
  const [content, setContent] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [newTag, setNewTag] = useState("")
  const [inputType, setInputType] = useState<"text" | "link">("text")

  const handleSave = () => {
    if (!content.trim()) return

    onSave({
      content: content.trim(),
      tags,
      type: inputType,
    })

    setContent("")
    setTags([])
    setNewTag("")
    onClose()
  }

  const addTag = (tag: string) => {
    if (tag && !tags.includes(tag)) {
      setTags([...tags, tag])
    }
    setNewTag("")
  }

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-background rounded-xl shadow-2xl w-full max-w-md animate-in slide-in-from-bottom-4 duration-300">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Quick Clip</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-4 space-y-4">
          {/* Input Type Toggle */}
          <div className="flex space-x-2">
            <Button
              variant={inputType === "text" ? "default" : "outline"}
              size="sm"
              onClick={() => setInputType("text")}
              className="flex-1"
            >
              <Type className="h-4 w-4 mr-2" />
              Text
            </Button>
            <Button
              variant={inputType === "link" ? "default" : "outline"}
              size="sm"
              onClick={() => setInputType("link")}
              className="flex-1"
            >
              <Link className="h-4 w-4 mr-2" />
              Link
            </Button>
          </div>

          {/* Content Input */}
          <Textarea
            placeholder={inputType === "text" ? "What's on your mind?" : "Paste a link or URL..."}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[100px] resize-none"
            autoFocus
          />

          {/* Tags Section */}
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center">
              <Tag className="h-4 w-4 mr-1" />
              Tags
            </label>

            {/* Selected Tags */}
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {tags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
                    onClick={() => removeTag(tag)}
                  >
                    {tag} ×
                  </Badge>
                ))}
              </div>
            )}

            {/* Add New Tag */}
            <div className="flex space-x-2">
              <Input
                placeholder="Add tag..."
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && addTag(newTag)}
                className="flex-1"
              />
              <Button variant="outline" size="sm" onClick={() => addTag(newTag)} disabled={!newTag.trim()}>
                Add
              </Button>
            </div>

            {/* Suggested Tags */}
            <div className="flex flex-wrap gap-1">
              {SUGGESTED_TAGS.filter((tag) => !tags.includes(tag)).map((tag) => (
                <Badge
                  key={tag}
                  variant="outline"
                  className="cursor-pointer hover:bg-accent hover:text-accent-foreground"
                  onClick={() => addTag(tag)}
                >
                  + {tag}
                </Badge>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-2 pt-2">
            <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={!content.trim()} className="flex-1">
              Save Clip
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export interface Clip {
  id: string
  userId: string
  title?: string
  content: string
  tags: string[]
  isPinned: boolean
  isArchived: boolean
  createdAt: Date
  updatedAt: Date
}

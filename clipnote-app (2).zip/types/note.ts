export interface Note {
  id: string
  content: string
  tags: string[]
  type: "text" | "link"
  createdAt: Date
}

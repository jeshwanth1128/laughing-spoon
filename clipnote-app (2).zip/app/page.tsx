"use client"

import { Suspense } from "react"
import { AuthProvider } from "@/components/auth-provider"
import { Header } from "@/components/header"
import { ClipManager } from "@/components/clip-manager"
import { AuthModal } from "@/components/auth-modal"
import { NotificationSystem } from "@/components/notification-system"
import { useTheme } from "@/hooks/use-theme"
import { useState, useEffect } from "react"

// Loading fallback component
function LoadingFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-black border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-black">Loading TRANSFORM...</p>
      </div>
    </div>
  )
}

// Main app content component
function AppContent() {
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [mounted, setMounted] = useState(false)
  const { theme } = useTheme()

  // Ensure component is mounted before rendering
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <LoadingFallback />
  }

  return (
    <div className={`min-h-screen transition-all duration-300 ${theme === "dark" ? "dark" : ""}`}>
      <div className="bg-background text-foreground">
        <Header onShowAuth={() => setShowAuthModal(true)} />
        <main className="container mx-auto px-4 py-6">
          <Suspense fallback={<LoadingFallback />}>
            <ClipManager />
          </Suspense>
        </main>
        {showAuthModal && (
          <Suspense fallback={null}>
            <AuthModal onClose={() => setShowAuthModal(false)} />
          </Suspense>
        )}
        <NotificationSystem />
      </div>
    </div>
  )
}

// Main page component with error boundary
export default function Home() {
  const [hasError, setHasError] = useState(false)

  useEffect(() => {
    // Global error handler
    const handleError = (error: ErrorEvent) => {
      console.error("Global error:", error)
      setHasError(true)
    }

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      console.error("Unhandled promise rejection:", event.reason)
      setHasError(true)
    }

    window.addEventListener("error", handleError)
    window.addEventListener("unhandledrejection", handleUnhandledRejection)

    return () => {
      window.removeEventListener("error", handleError)
      window.removeEventListener("unhandledrejection", handleUnhandledRejection)
    }
  }, [])

  if (hasError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center p-8">
          <h1 className="text-2xl font-bold text-black mb-4">Something went wrong</h1>
          <p className="text-gray-600 mb-4">Please refresh the page to try again.</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-black text-white rounded hover:bg-gray-800 transition-colors"
          >
            Refresh Page
          </button>
        </div>
      </div>
    )
  }

  return (
    <AuthProvider>
      <Suspense fallback={<LoadingFallback />}>
        <AppContent />
      </Suspense>
    </AuthProvider>
  )
}

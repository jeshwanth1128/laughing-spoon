import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  fallback: ["system-ui", "arial"],
})

export const metadata: Metadata = {
  title: "TRANSFORM - Intelligent Clip Organizer",
  description: "An intelligent note-saving and tag-based clip organizer app with a sleek UI",
  viewport: "width=device-width, initial-scale=1",
  themeColor: "#000000",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className={`${inter.className} antialiased`} suppressHydrationWarning>
        <noscript>
          <div
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: "white",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 9999,
            }}
          >
            <div style={{ textAlign: "center", padding: "20px" }}>
              <h1 style={{ color: "black", marginBottom: "10px" }}>JavaScript Required</h1>
              <p style={{ color: "#666" }}>Please enable JavaScript to use TRANSFORM.</p>
            </div>
          </div>
        </noscript>
        {children}
      </body>
    </html>
  )
}
